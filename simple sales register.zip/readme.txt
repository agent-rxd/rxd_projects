This is simple daily sales registering tool for small shops . I have written this tool using python . I have also added a special feature using which you can export the daily sales history into a csv file . I will again mention that this is just a "Simple" tool . Download the source code and make any changes that you need .


If you wish to contact me , feel free to reach me through my social media handles.
